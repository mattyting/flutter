package com.example.connect_fire_db

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
