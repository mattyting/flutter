import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: HomeScreen());
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  // Function to write data to Firestore
  Future<void> _sendDataToFirestore() async {
    final db = FirebaseFirestore.instance;

    await db.collection("users").add({
      "first": "Matt",
      "last": "Yting",
      "born": 2005,
    });

    debugPrint("Data sent to Firestore successfully!");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Firebase Test')),
      body: Center(
        child: ElevatedButton(
          onPressed: _sendDataToFirestore,
          child: const Text('Click to Add Data to Firestore'),
        ),
      ),
    );
  }
}
